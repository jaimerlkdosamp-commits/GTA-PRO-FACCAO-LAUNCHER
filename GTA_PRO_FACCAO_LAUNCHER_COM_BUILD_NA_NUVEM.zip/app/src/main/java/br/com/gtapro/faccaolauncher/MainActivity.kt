package br.com.gtapro.faccaolauncher

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val serverIp = "135.148.164.122:21366"
    private val sampPackage = "com.samp.x1y2z"
    private val discordInvite = "https://discord.gg/GMw4mDg9sQ"
    private val gold = Color.rgb(218, 174, 70)
    private val background = Color.rgb(10, 10, 14)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = background
        window.navigationBarColor = Color.rgb(15, 15, 21)
        window.decorView.systemUiVisibility = 0
        buildScreen()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(background)
            isFillViewport = true
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
        }

        val brand = TextView(this).apply {
            text = "GTA PRO FACÇÃO"
            textSize = 27f
            setTextColor(gold)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        root.addView(brand, matchWrap())

        val subtitle = TextView(this).apply {
            text = "MOBILE LAUNCHER"
            textSize = 12f
            letterSpacing = 0.22f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, dp(16))
        }
        root.addView(subtitle, matchWrap())

        val poster = ImageView(this).apply {
            setImageResource(R.drawable.launcher_art)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.DKGRAY, 18)
            clipToOutline = true
            contentDescription = "Arte natalina do GTA PRO FACÇÃO"
        }
        root.addView(poster, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(390)
        ).apply { bottomMargin = dp(20) })

        val status = TextView(this).apply {
            text = "SERVIDOR OFICIAL"
            textSize = 13f
            letterSpacing = 0.12f
            setTextColor(gold)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(status, matchWrap())

        val ip = TextView(this).apply {
            text = serverIp
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(18))
        }
        root.addView(ip, matchWrap())

        val play = makeButton("JOGAR AGORA", gold, Color.BLACK)
        play.setOnClickListener { openSamp() }
        root.addView(play, buttonParams())

        val copy = makeButton("COPIAR IP DO SERVIDOR", Color.rgb(37, 37, 43), Color.WHITE)
        copy.setOnClickListener {
            val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("IP GTA PRO FACÇÃO", serverIp))
            Toast.makeText(this, "IP copiado: $serverIp", Toast.LENGTH_SHORT).show()
        }
        root.addView(copy, buttonParams())

        val discord = makeButton("ENTRAR NO DISCORD", Color.rgb(37, 37, 43), Color.WHITE)
        discord.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(discordInvite)))
        }
        root.addView(discord, buttonParams())

        val note = TextView(this).apply {
            text = "Para jogar, tenha o SAMP Mobile instalado. Se a conexão não iniciar automaticamente, adicione o IP acima na lista de servidores do cliente."
            textSize = 12f
            setTextColor(Color.rgb(175, 175, 182))
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(18), dp(8), 0)
        }
        root.addView(note, matchWrap())

        scroll.addView(root)
        setContentView(scroll)
    }

    private fun openSamp() {
        val launchIntent = packageManager.getLaunchIntentForPackage(sampPackage)
        if (launchIntent != null) {
            try {
                startActivity(launchIntent)
            } catch (_: ActivityNotFoundException) {
                showInstallMessage()
            }
        } else {
            showInstallMessage()
        }
    }

    private fun showInstallMessage() {
        Toast.makeText(
            this,
            "Instale o SAMP Mobile para continuar. O IP do servidor pode ser copiado nesta tela.",
            Toast.LENGTH_LONG
        ).show()
        startActivity(Intent(
            Intent.ACTION_VIEW,
            Uri.parse("https://play.google.com/store/apps/details?id=$sampPackage")
        ))
    }

    private fun makeButton(label: String, fill: Int, text: Int): Button =
        Button(this).apply {
            this.text = label
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(text)
            isAllCaps = false
            background = rounded(fill, 14)
            stateListAnimator = null
            minHeight = dp(54)
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun buttonParams() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, dp(56)
    ).apply { bottomMargin = dp(11) }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
