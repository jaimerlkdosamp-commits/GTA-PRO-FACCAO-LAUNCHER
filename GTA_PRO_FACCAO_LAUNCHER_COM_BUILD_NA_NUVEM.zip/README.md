# GTA PRO FACÇÃO — Android Launcher (protótipo)

Este é o projeto-fonte inicial de um launcher Android independente.

## O que já está implementado
- Tela inicial com a arte enviada para o GTA PRO FACÇÃO.
- Identidade visual escura com detalhes dourados.
- IP do servidor: `135.148.164.122:21366`.
- Botão para abrir o aplicativo SAMP Mobile (`com.samp.x1y2z`).
- Botão para copiar o IP.
- Botão para abrir o Discord da comunidade.

## Limitação importante da primeira versão
O botão **JOGAR AGORA** abre o SAMP Mobile. Esta versão ainda não envia automaticamente o IP para dentro do cliente, porque isso depende de um deep link, intent ou API de conexão oficialmente suportado pelo SAMP Mobile. Até confirmar esse mecanismo, o jogador pode precisar adicionar/selecionar o servidor dentro do cliente.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `GTAProFaccaoLauncher` no Android Studio.
3. Aguarde a sincronização do Gradle e a instalação dos componentes Android solicitados.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de debug ficará em `app/build/outputs/apk/debug/app-debug.apk`.

Configuração do app:
- Application ID: `br.com.gtapro.faccaolauncher`
- Versão: `1.0`
- Cliente alvo: `com.samp.x1y2z`
- Android mínimo: 6.0 (API 23)

## Próximo teste necessário
Instalar no aparelho que já possui o SAMP Mobile e verificar se o botão abre o cliente. Depois, confirmar se o cliente aceita algum link externo para conectar diretamente ao IP/porta.


## Gerar APK usando GitHub Actions (sem computador)

O ZIP inclui um workflow em `.github/workflows/android-apk.yml` para compilar o APK na nuvem.

1. No Android, entre em https://github.com e crie uma conta ou faça login.
2. Crie um repositório novo e envie os arquivos que estão dentro da pasta `GTAProFaccaoLauncher` (não envie a pasta externa que contém tudo).
3. Aguarde o workflow `Build Android APK` terminar na aba **Actions**.
4. Abra a execução concluída, vá até **Artifacts** e baixe `GTA-Pro-Faccao-debug-apk`.
5. Extraia o arquivo baixado e instale `app-debug.apk` no Android. Talvez seja necessário autorizar a instalação de apps dessa fonte.

O workflow é uma alternativa de compilação remota; ele não significa que o APK já foi compilado ou testado.

**Atenção:** o botão JOGAR desta versão abre o app SAMP Mobile. A conexão direta ao IP ainda depende de o cliente aceitar um link/intent externo compatível e precisa ser testada no aparelho.
